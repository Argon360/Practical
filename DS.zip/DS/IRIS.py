import pandas as pd

# Load Iris dataset
iris = pd.read_csv("Iris.csv")

# Display the loaded dataset
print("Original Iris DataFrame:")
print(iris)

# Importing LabelEncoder
from sklearn.preprocessing import LabelEncoder

# Initializing LabelEncoder
le = LabelEncoder()

# Encoding the 'Species' column and storing the encoded values in a new column 'code'
iris['code'] = le.fit_transform(iris['Species'])

# Display the DataFrame with encoded 'Species' column
print("\nIris DataFrame with encoded 'Species' column:")
print(iris)
