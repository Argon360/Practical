csv & json

import pandas as pd
# Specify the path to CSV file
csv_file_path = 'Crescent.csv'
# Function to read CSV file
def read_csv_file(file_path):
 try:
 # Read the CSV file into a pandas DataFrame
  data_frame = pd.read_csv(file_path)
  return data_frame
 except FileNotFoundError:
  print(f"Error: File not found at path '{file_path}'")
# Call the function to read the CSV file
csv_data = read_csv_file(csv_file_path)
# Print the DataFrame
if csv_data is not None:
  print("CSV Data:")
  print(csv_data)




*json*

import json
# Specify the path to your JSON file
json_file_path = 'prac.json'
# Function to read JSON file
def read_json_file(file_path):
 with open(file_path, 'r') as file:
 # Load the JSON data from the file
        data = json.load(file)
        return data
# Call the function to read the JSON file
try:
        json_data = read_json_file(json_file_path)
 # Print the JSON data with indentation for better readability
        print("JSON Data:") 
        print(json.dumps(json_data, indent=2))
except FileNotFoundError:
      print(f"Error: File not found at path '{json_file_path}'")
except json.JSONDecodeError:
      print(f"Error: Invalid JSON format in file at path '{json_file_path}'")
