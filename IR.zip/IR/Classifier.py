
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report

# Load the CSV file
df = pd.read_csv(r"C:\Users\nisha\OneDrive\Downloads\Dataset.csv")

# Assuming you want to concatenate the 'covid' and 'fever' columns into a single text feature
data = df["covid"].astype(str) + " " + df["fever"].astype(str)

X = data  # This is your feature set
y = df['flu']  # Assuming 'flu' is your label

# Splitting the data into training and test data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Convert your text data into a format that the model can work with
vectorizer = CountVectorizer()
X_train_counts = vectorizer.fit_transform(X_train)
X_test_counts = vectorizer.transform(X_test)

# Training the Naive Bayes model
clf = MultinomialNB()
clf.fit(X_train_counts, y_train)

# Making predictions
y_pred = clf.predict(X_test_counts)

# Evaluating the model
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# Assuming you want to add predictions to the test portion of your original DataFrame
# First, create a DataFrame from y_pred
predictions_df = pd.DataFrame(y_pred, columns=['Predicted_flu'])

# Reset index on X_test to concatenate correctly
X_test_reset = X_test.reset_index(drop=True)

# Concatenate X_test DataFrame with the predictions DataFrame
# Note: Ensure that X_test is a DataFrame; if X_test is a Series, convert it to DataFrame or adjust accordingly
results_df = pd.concat([X_test_reset, predictions_df], axis=1)

# Assuming you want to save the results back to a new CSV file
results_df.to_csv(r"C:\Users\nisha\OneDrive\Downloads\test.csv", index=False)
